# Date    : 10/09/22 10:31 pm
# Author  : dencoder (hetcjoshi1684@gmail.com)
# GitHub    : (https://github.com/D-ENCODER)
# Twitter    : (https://twitter.com/Hetjoshi1684)
# Version : 1.0.0
import string
import itertools


class PlayfairCipher:
    """
    def encrypt(self): to encrypt the text in playfair cipher\n
    def decrypt(self): to decrypt the text in playfair cipher
    """

    @staticmethod
    def chunker(seq, size):
        """
        :param seq: sequence to chunk (str)
        :param size: size of chunk (int)
        :return: chunked sequence (str)
        """
        it = iter(seq)
        while True:
            chunk = tuple(itertools.islice(it, size))
            if not chunk:
                return
            yield chunk

    @staticmethod
    def prepare_input(dirty):
        """
        :param dirty: dirty input (str)
        :return: clean input (str)
        """
        temp = "".join([c.lower() for c in dirty if c in string.ascii_letters])
        clean = ""
        if len(temp) < 2:
            return temp
        for i in range(len(temp) - 1):
            clean += temp[i]
            if temp[i] == temp[i + 1]:
                clean += "X"
        clean += temp[-1]
        if len(clean) & 1:
            clean += "X"
        return clean

    @staticmethod
    def generate_table(key):
        """
        :param key: key to generate table (str)
        :return: table (str)
        """
        alphabet = "abcdefghiklmnopqrstuvwxyz"
        table = []
        for char in key.lower():
            if char not in table and char in alphabet:
                table.append(char)
        for char in alphabet:
            if char not in table:
                table.append(char)
        return table

    def encrypt(self, plaintext, key):
        """
        :param plaintext: plaintext to encrypt (str)
        :param key: key to encrypt the text (str)
        :return: encrypted text (str)
        """
        table = self.generate_table(key)
        plaintext = self.prepare_input(plaintext)
        ciphertext = ""
        for char1, char2 in self.chunker(plaintext, 2):
            row1, col1 = divmod(table.index(char1), 5)
            row2, col2 = divmod(table.index(char2), 5)
            if row1 == row2:
                ciphertext += table[row1 * 5 + (col1 + 1) % 5]
                ciphertext += table[row2 * 5 + (col2 + 1) % 5]
            elif col1 == col2:
                ciphertext += table[((row1 + 1) % 5) * 5 + col1]
                ciphertext += table[((row2 + 1) % 5) * 5 + col2]
            else:
                ciphertext += table[row1 * 5 + col2]
                ciphertext += table[row2 * 5 + col1]
        return ciphertext

    def decrypt(self, ciphertext, key):
        """
        :param ciphertext: ciphertext to decrypt (str)
        :param key: key to decrypt the text (str)
        :return: decrypted text (str)
        """
        table = self.generate_table(key)
        plaintext = ""
        for char1, char2 in self.chunker(ciphertext, 2):
            row1, col1 = divmod(table.index(char1), 5)
            row2, col2 = divmod(table.index(char2), 5)
            if row1 == row2:
                plaintext += table[row1 * 5 + (col1 - 1) % 5]
                plaintext += table[row2 * 5 + (col2 - 1) % 5]
            elif col1 == col2:
                plaintext += table[((row1 - 1) % 5) * 5 + col1]
                plaintext += table[((row2 - 1) % 5) * 5 + col2]
            else:
                plaintext += table[row1 * 5 + col2]
                plaintext += table[row2 * 5 + col1]
        plaintext = plaintext[0:-1]
        return plaintext
